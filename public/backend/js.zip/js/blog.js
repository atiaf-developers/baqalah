
    var products_id;
    var product_trip_rates_id;
    var Program_type;
    var Blog_grid;
    var Products_images_grid;
    var Products_features_grid;
    var productTypeFormData;
    var images_ids = {};
    var Blog = function () {

        var init = function () {
            //alert('here');
            $.extend(lang, new_lang);
            handleRecords();
            handleShowInSlider();
            handleSubmit();
            handleImagesFormSubmit();
            readImage();
            remove_image();
            handleCheckImagesForDelete();
        };

        var readImage = function (input) {
            $("#blog_image").change(function () {
                for (var i = 0; i < $(this)[0].files.length; i++) {
                    var reader = new FileReader();

                    reader.onload = function (e) {
                        $('.image_uploaded').html('<img style="height:80px;width:150px;" id="image_upload_preview" src="' + e.target.result + '" alt="your image" />');
                    }

                    reader.readAsDataURL($(this)[0].files[i]);
                }

                //readURL(this);
            });


        }
    
        var handleRecords = function () {
            var _token = $('input[name="_token"]').val();
            Blog_grid = $('#blog_table .dataTable').dataTable({
                //"processing": true,
                "serverSide": true,
                "ajax": {
                    "url": config.admin_url + "/blog/data",
                    "type": "POST",
                    data: { _token : $('input[name="_token"]').val() },
                },
                "columns": [
//                    {"data": "user_input", orderable: false, "class": "text-center"},
                    {"data": "title_en"},
                    {"data": "image"},
                    {"data": "active"},
                    {"data": "created_at"},
                    {"data": "options", orderable: false}
                ],
                "order": [
                    [1, "desc"]
                ]

            });
        }
        var handleSubmit = function () {

            $('#addEditBlogForm').validate({
                rules: {
                   title_en: {
                       required: true,
                   },
                   desc_en: {
                       required: true,
                   },
                   this_order: {
                       required: true

                   },
                },
                messages: lang.messages,
                highlight: function (element) { // hightlight error inputs
                    $(element).closest('.form-group').removeClass('has-success').addClass('has-error');

                },
                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
                    $(element).closest('.form-group').find('.help-block').html('').css('opacity', 0);

                },
                errorPlacement: function (error, element) {
                    $(element).closest('.form-group').find('.help-block').html($(error).html()).css('opacity', 1);
                }
            });
            $('#addEditBlog .submit-form').click(function () {
                if ($('#addEditBlogForm').validate().form()) {
                    $('#addEditBlogForm').submit();
                }
                return false;
            });
            $('#addEditBlogForm input').keypress(function (e) {
                if (e.which == 13) {
                    if ($('#addEditBlogForm').validate().form()) {
                        $('#addEditBlogForm').submit();
                    }
                    return false;
                }
            });



            $('#addEditBlogForm').submit(function () {
                var id = $('#id').val();
                var formData = new FormData($(this)[0]);
                var action = config.admin_url + '/blog/create';
                if (id != 0) {
                    formData.append('_method', 'PATCH');
                    action = config.admin_url + '/blog/'+id+'/edit';
                }
                
                $.ajax({
                    url: action,
                    data: formData,
                    async: false,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (data) {
                        console.log(data);

                        if (data.type == 'success')
                        {
                            toastr.options = {
                                "debug": false,
                                "positionClass": "toast-bottom-left",
                                "onclick": null,
                                "fadeIn": 300,
                                "fadeOut": 1000,
                                "timeOut": 5000,
                                "extendedTimeOut": 1000
                            };
                            toastr.success(data.message, 'رسالة');
                            Blog_grid.api().ajax.reload();
                            if (id != 0) {
                                $('#addEditBlog').modal('hide');
                            } else {
                                Blog.empty();
                            }

                        } else {
                            console.log(data)
                            if (typeof data.errors === 'object') {
                                for (i in data.errors)
                                {
                                    $('[name="' + i + '"]')
                                            .closest('.form-group').addClass('has-error');
                                    $('#' + i).parent().find(".help-block").html(data.errors[i]).css('opacity', 1)
                                }
                            } else {
                                $.confirm({
                                    title: lang.error,
                                    content: data.message,
                                    type: 'red',
                                    typeAnimated: true,
                                    buttons: {
                                        tryAgain: {
                                            text: lang.try_again,
                                            btnClass: 'btn-red',
                                            action: function () {
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    },
                    error: function (xhr, textStatus, errorThrown) {
                        $('.loading').addClass('hide');
                        bootbox.dialog({
                            message: xhr.responseText,
                            title: 'رسالة تنبيه',
                            buttons: {
                                danger: {
                                    label: 'اغلاق',
                                    className: "red"
                                }
                            }
                        });
                    },
                    dataType: "json",
                    type: "POST"
                });

                return false;

            })




        }
    
        var handleImagesFormSubmit = function () {
            
            var action = config.admin_url + '/products/'+products_id+'/gallery';
            $('#addEditBlogImages .submit-form').click(function () {
                $('#addEditBlogImages .submit-form').prop('disabled', true);
                $('#addEditBlogImages .submit-form').html(lang.uploading + ' ......');
                var inputFile = $('#product_images');
                var formData = new FormData($("#addEditBlogImagesForm")[0]);
                var fileToUpload = inputFile[0].files;
                //return false;
                for (var x = 0; x < fileToUpload.length; x++) {
                    formData.append('file[]', fileToUpload[x]);
                }

                $.ajax({
                    url: action,
                    data: formData,
                    async: false,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (data) {
                        console.log(data);

                        if (data.type == 'success')
                        {
                            setTimeout(function () {
                                handleListImagesOnServer(products_id);
                                $('#addEditBlogImages .submit-form').prop('disabled', false);
                                $('#addEditBlogImages .submit-form').html(lang.upload);
                            }, 3000);

                        } else {
                            console.log(data)
                            if (typeof data.errors === 'object') {

                                var items = [];
                                $.each(data.errors, function (i, element) {
                                    items.push('<li class="list-group-item">' + i + ' : ' + element + '</li>');
                                });
                                console.log(items);
                                $("#files-not-uploaded").html('').html(items.join(''));

                            } else {
                                $.confirm({
                                    title: lang.error,
                                    content: data.message,
                                    type: 'red',
                                    typeAnimated: true,
                                    buttons: {
                                        tryAgain: {
                                            text: lang.try_again,
                                            btnClass: 'btn-red',
                                            action: function () {
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    },
                    error: function (xhr, textStatus, errorThrown) {
                        $('.loading').addClass('hide');
                        bootbox.dialog({
                            message: xhr.responseText,
                            title: 'رسالة تنبيه',
                            buttons: {
                                danger: {
                                    label: 'اغلاق',
                                    className: "red"
                                }
                            }
                        });
                    },
                    dataType: "json",
                    type: "POST"
                });
                return false;
            });
        }
        var handleListImagesOnServer = function (products_id) {
            var action = config.admin_url + '/products/'+products_id+'/gallery';
            $.ajax({
                url: action,
                async: false,
                success: function (data) {
                    console.log(data);

                    if (data.type == 'success')
                    {
                        var items = [];
                        var count = 1;
                        for (var x = 0; x < data.data.length; x++) {
                            var image_id = 'product_images_' + count;
                            var html = '<div style="position:relative;float:right;padding: 5px 5px;">' +
                                    '<img style="height:80px;width:80px;" src="' + config.base_url + 'uploads/products_slider/' + data.data[x].image + '"/>' +
                                    '<div style="position: absolute; top: 4px; left: 4px; width: 15px; height: 15px; text-align: center; line-height: 15px; border-radius: 50px;">' +
                                    '<div class="md-checkbox">' +
                                    ' <input type="checkbox" id="' + image_id + '"  name="product_images[]"  value="' + data.data[x].id + '" class="product_image md-check">' +
                                    '<label for="' + image_id + '">' +
                                    ' <span></span>' +
                                    '<span class="check"></span>' +
                                    '<span class="box" style="background-color: #fff;border: 2px solid #888;"></span></label>' +
                                    '</div>' +
                                    '</div>' +
                                    '</div>';
//                            var html = '<div style="position:relative;float:right;padding: 5px 5px;"><img style="height:80px;width:80px;" src="' + config.base_url + 'uploads/products_slider/' + data.data[x].image + '"/><div style="position: absolute; top: -3px; left: 4px; width: 15px; height: 15px; text-align: center; line-height: 15px; background: #ab0101; border-radius: 50px;"><a href="" class="product_image" data-id="' + data.data[x].id + '" data-product-id="' + data.data[x].products_id + '" data-image="' + data.data[x].image + '" style="color:#fff;">x</a></div></div>';

                            items.push(html);
                            count++;
                        }
                        $("#products-images-box").html('').html(items.join(''));

                    } else {
                        $("#products-images-box").html('');
                    }
                },
                error: function (xhr, textStatus, errorThrown) {
                    $('.loading').addClass('hide');
                    bootbox.dialog({
                        message: xhr.responseText,
                        title: 'رسالة تنبيه',
                        buttons: {
                            danger: {
                                label: 'اغلاق',
                                className: "red"
                            }
                        }
                    });
                },
                dataType: "json",
                type: "GET"
            });
        }
        var handleCheckImagesForDelete = function () {
            $(document).on('change', '.product_image', function () {
                images_ids = {};
                var count = 0;
                $(".product_image").each(function () {
                    var input_id = $(this).attr('id');
                    var value = $(this).val();
                    if ($(this).is(':checked')) {
                        //alert(input_id);
                        images_ids[input_id] = value;
                        count++;
                    } else {
                        //alert('here');
                        delete images_ids[input_id];
                    }
                });
                if (count > 0) {
                    $('.delete-product-images').prop('disabled', false);
                } else {
                    $('.delete-product-images').prop('disabled', true);
                }
                console.log(images_ids);

            });

        }
        var remove_image = function () {
            $(document).on('click', '.delete-product-images', function () {
                $('.delete-product-images').prop('disabled', true);
                $('.delete-product-images').html(lang.deleting + ' ......');
                var action = config.admin_url + '/products/remove_image';

                $.ajax({
                    url: action,
                    data: $.param(images_ids),
                    async: false,
                    success: function (data) {
                        console.log(data);

                        if (data.type == 'success')
                        {

                            setTimeout(function () {
                                handleListImagesOnServer(products_id);
                                $('.delete-product-images').prop('disabled', false);
                                $('.delete-product-images').html(lang.delete);
                            }, 3000);


                        }
                    },
                    error: function (xhr, textStatus, errorThrown) {
                        $('.loading').addClass('hide');
                        bootbox.dialog({
                            message: xhr.responseText,
                            title: 'رسالة تنبيه',
                            buttons: {
                                danger: {
                                    label: 'اغلاق',
                                    className: "red"
                                }
                            }
                        });
                    },
                    dataType: "json",
                    type: "POST"
                });
                return false;
            });

        }
        var handleShowInSlider = function () {
            $('#show_in_slider').on('change', function () {
                var show_in_slider = $(this).val();
                if (show_in_slider == 1) {
                    $('#slider-image-upload-box').slideDown(500);
                    $("#prog_slider_image").rules("add", {
                        required: true,
                        messages: {
                            required: "لا يوجد ملف للرفع",
                        }
                    });
                } else {
                    $("#prog_slider_image").rules("remove", "required");
                    $("#prog_slider_image").closest('.form-group').removeClass('has-error');
                    $("#prog_slider_image").closest('.form-group').find('.help-block').html('');
                    $('#slider-image-upload-box').slideUp(500);
                }
            });
        }

        return {
            init: function () {
                init();
            },
            edit: function (t) {



                My.editForm({
                    element: t,
                    url: config.admin_url + '/blog/'+$(t).attr("data-id")+'/edit',
                    success: function (data)
                    {
                        console.log(data);

                        Blog.empty();
                        My.setModalTitle('#addEditBlog', lang.edit_product);

                        for (i in data.message)
                        {
                            if (i == 'image') {
                                //$('#product_image').val(data.message[i]);
                                $('.image_uploaded').html('<img style="height:80px;width:150px;" id="image_upload_preview" src="' + config.asset_url + '/uploads/blog/' + data.message[i] + '" alt="your image" />');
                            } else if (i == 'main_categories_id') {
                                $('#' + i).val(data.message[i]);
                            } else {
                                $('#' + i).val(data.message[i]);
                            }

                        }
                        $('#addEditBlog').modal('show');
                    }
                });

            },
            delete: function (t) {
                var _token = $('input[name="_token"]').val();
                My.deleteForm({
                    element: t,
                    url: config.admin_url + '/blog/'+$(t).attr("data-id")+'/delete',
                    data: {id: $(t).attr("data-id"),_method:'DELETE',_token:_token},
                    success: function (data)
                    {

                        Blog_grid.api().ajax.reload();


                    }
                });

            },
            add: function () {
                Blog.empty();
                My.setModalTitle('#addEditBlog', lang.add_product);
                $('#addEditBlog').modal('show');
            },
            gallery: function (element) {
                products_id = $(element).data('id');
                //alert(products_id);
                $("#products-images-box").html('');
                $("#product_images").val('');
                handleListImagesOnServer(products_id);
                My.setModalTitle('#addEditBlogImages', lang.add_products_images);
                $('#addEditBlogImages').modal('show');
            },
            empty: function () {
                $('#id').val(0);
                $('#blog_image').val('');
                $('.image_uploaded').html('<img src="' + config.base_url + 'no-image.jpg" width="150" height="80" />');
                $('.has-error').removeClass('has-error');
                $('.has-success').removeClass('has-success');
                $('.help-block').html('');
                My.emptyForm();
            },
        };

    }();
    jQuery(document).ready(function () {
        Blog.init();
    });

